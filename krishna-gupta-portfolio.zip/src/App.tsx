import { Hero } from './components/Hero';
import { About } from './components/About';
import { Research } from './components/Research';
import { InteractiveLogs } from './components/InteractiveLogs';
import { Social } from './components/Social';
import { BootAnimation } from './components/BootAnimation';
import { ScrollProgress } from './components/ScrollProgress';
import { CEOStatement } from './components/CEOStatement';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans selection:bg-[#4285F4]/30 selection:text-blue-200 relative overflow-hidden">
      <BootAnimation />
      <ScrollProgress />
      <CEOStatement />
      
      {/* Ambient background glows (Googliness) */}
      <div className="fixed top-[-20%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-[#4285F4]/10 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: "8s" }} />
      <div className="fixed top-[20%] right-[-10%] w-[40vw] h-[40vw] rounded-full bg-[#EA4335]/5 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: "12s" }} />
      <div className="fixed bottom-[-10%] left-[20%] w-[45vw] h-[45vw] rounded-full bg-[#FBBC05]/5 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: "10s" }} />
      <div className="fixed bottom-[-20%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-[#34A853]/10 blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: "9s" }} />
      
      <main className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-24 relative z-10">
        <Hero />
        <About />
        <Research />
        <InteractiveLogs />
        <Social />
      </main>
      
      <footer className="py-8 text-center text-slate-500 text-sm border-t border-slate-800/50 relative z-10">
        <p>&copy; {new Date().getFullYear()} Krishna Gupta. All rights reserved.</p>
      </footer>
    </div>
  );
}



