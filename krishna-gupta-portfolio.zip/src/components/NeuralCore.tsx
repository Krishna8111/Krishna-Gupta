import { useEffect, useRef, useState } from "react";
import { Cpu, Zap } from "lucide-react";

export function NeuralCore() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [cognitiveFrequency, setCognitiveFrequency] = useState(8.4);
  const [clickWave, setClickWave] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = 300);
    let height = (canvas.height = 300);
    let angle = 0;
    
    // Generate particle points orbiting the center
    const particles: { angle: number; radius: number; size: number; color: string; speed: number }[] = [];
    const colors = ["#4285F4", "#EA4335", "#FBBC05", "#34A853"];
    
    for (let i = 0; i < 40; i++) {
      particles.push({
        angle: Math.random() * Math.PI * 2,
        radius: 40 + Math.random() * 80,
        size: 1 + Math.random() * 2.5,
        color: colors[i % colors.length],
        speed: (0.005 + Math.random() * 0.01)
      });
    }

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = canvas.parentElement?.clientWidth || 300;
        height = canvas.height = canvas.parentElement?.clientHeight || 300;
      }
    };
    window.addEventListener("resize", handleResize);
    handleResize();

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      const centerX = width / 2;
      const centerY = height / 2;

      // Draw subtle backing glowing rings
      ctx.strokeStyle = "rgba(66, 133, 244, 0.05)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 50, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = "rgba(234, 67, 53, 0.03)";
      ctx.beginPath();
      ctx.arc(centerX, centerY, 90, 0, Math.PI * 2);
      ctx.stroke();

      // Draw Neural center glow
      const baseRadius = 35 + Math.sin(angle * 2) * 4;
      const gradient = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        baseRadius * 1.5
      );
      gradient.addColorStop(0, "rgba(66, 133, 244, 0.4)");
      gradient.addColorStop(0.3, "rgba(234, 67, 53, 0.15)");
      gradient.addColorStop(0.6, "rgba(251, 188, 5, 0.05)");
      gradient.addColorStop(1, "rgba(0, 0, 0, 0)");

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 1.5, 0, Math.PI * 2);
      ctx.fill();

      // Draw solid center core
      ctx.fillStyle = "rgba(7, 11, 25, 0.9)";
      ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Draw dynamic network connections between particles
      ctx.lineWidth = 0.5;
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];
        const x1 = centerX + Math.cos(p1.angle) * p1.radius;
        const y1 = centerY + Math.sin(p1.angle) * p1.radius;

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const x2 = centerX + Math.cos(p2.angle) * p2.radius;
          const y2 = centerY + Math.sin(p2.angle) * p2.radius;
          const dist = Math.hypot(x2 - x1, y2 - y1);

          if (dist < 45) {
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.15 - dist / 300})`;
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
          }
        }
      }

      // Draw and update orbiting particles
      particles.forEach((p) => {
        p.angle += p.speed * speedMultiplier;
        const x = centerX + Math.cos(p.angle) * p.radius;
        const y = centerY + Math.sin(p.angle) * p.radius;

        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(x, y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0; // reset
      });

      // Interactive shockwave logic
      if (clickWave) {
        ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(centerX, centerY, baseRadius * 3, 0, Math.PI * 2);
        ctx.stroke();
      }

      angle += 0.02 * speedMultiplier;
      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, [speedMultiplier, clickWave]);

  const handleInteraction = () => {
    setSpeedMultiplier(4.5);
    setCognitiveFrequency(16.0);
    setClickWave(true);
    setTimeout(() => {
      setSpeedMultiplier(1);
      setCognitiveFrequency(8.4);
      setClickWave(false);
    }, 1500);
  };

  return (
    <div 
      className="relative w-full aspect-square max-w-[340px] mx-auto flex items-center justify-center group cursor-pointer"
      onClick={handleInteraction}
      onMouseEnter={() => {
        setSpeedMultiplier(2.5);
        setCognitiveFrequency(12.8);
      }}
      onMouseLeave={() => {
        setSpeedMultiplier(1);
        setCognitiveFrequency(8.4);
      }}
    >
      {/* Decorative Outer HUD Rings */}
      <div className="absolute inset-0 border border-slate-800/60 rounded-full animate-[spin_40s_linear_infinite] pointer-events-none" />
      <div className="absolute inset-4 border border-dashed border-slate-800/40 rounded-full animate-[spin_20s_linear_infinite_reverse] pointer-events-none" />
      
      {/* Real Canvas Rendering */}
      <canvas ref={canvasRef} className="absolute inset-0 z-10 w-full h-full" />

      {/* Embedded HUD Telemetry Panel */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/90 border border-slate-800/80 px-4 py-2 rounded-xl text-[10px] font-mono text-slate-400 z-20 flex flex-col gap-1 backdrop-blur-md shadow-lg shadow-black/40 min-w-[200px]">
        <div className="flex items-center justify-between text-blue-400 font-bold border-b border-slate-800/80 pb-1 mb-1">
          <span className="flex items-center gap-1">
            <Cpu className="w-3 h-3 text-blue-400" /> COGNITIVE CORE
          </span>
          <span className="animate-pulse flex items-center gap-1">
            <Zap className="w-2.5 h-2.5 text-yellow-500" /> HYPER
          </span>
        </div>
        <div className="flex justify-between">
          <span>FREQUENCY:</span>
          <span className="text-slate-200 font-bold transition-all">{cognitiveFrequency.toFixed(1)} GHz</span>
        </div>
        <div className="flex justify-between">
          <span>THINKING STATE:</span>
          <span className="text-[#34A853] font-bold">OPTIMAL</span>
        </div>
        <div className="flex justify-between">
          <span>COGNITIVE FLOW:</span>
          <span className="text-slate-200">98.4%</span>
        </div>
      </div>
    </div>
  );
}
