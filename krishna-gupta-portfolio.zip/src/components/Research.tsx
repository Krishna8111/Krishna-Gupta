import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Terminal, FileCode, CheckCircle, Shield, Accessibility, Layers, Zap, Database, Cpu, Eye, ArrowUpRight } from "lucide-react";

type TabId = "ux_research" | "accessibility" | "stateless_search";

interface FileItem {
  id: TabId;
  name: string;
  lang: string;
  size: string;
  icon: typeof FileCode;
}

const FILES: FileItem[] = [
  {
    id: "ux_research",
    name: "google_ux_research.md",
    lang: "Markdown",
    size: "2.4 KB",
    icon: FileCode
  },
  {
    id: "accessibility",
    name: "universal_accessibility.json",
    lang: "JSON",
    size: "4.1 KB",
    icon: FileCode
  },
  {
    id: "stateless_search",
    name: "stateless_search_engine.rs",
    lang: "Rust",
    size: "1.8 KB",
    icon: FileCode
  }
];

export function Research() {
  const [activeTab, setActiveTab] = useState<TabId>("ux_research");
  const [activeWatchHaptics, setActiveWatchHaptics] = useState(false);

  return (
    <section id="research" className="py-24 border-t border-slate-800/30" aria-labelledby="research-heading">
      <div className="mb-12">
        <h2 id="research-heading" className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-50 mb-4 tracking-tight">
          Identity Terminals & Case Studies
        </h2>
        <p className="text-slate-400 text-lg max-w-2xl font-light">
          An interactive Google Developer IDE showcasing core focus pillars, theoretical frameworks, and research logs.
        </p>
      </div>

      {/* Futuristic IDE / Google Research Dashboard */}
      <div className="w-full neon-glow-container rounded-2xl overflow-hidden shadow-2xl shadow-black/80 flex flex-col lg:flex-row min-h-[600px]">
        
        {/* Left Sidebar: File Tree Navigator */}
        <div className="w-full lg:w-64 bg-slate-900/40 border-r border-slate-800/80 p-4 font-mono text-xs flex flex-col gap-6 relative z-10">
          <div>
            <div className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-3 px-2">PROJECT NAVIGATOR</div>
            <div className="space-y-1">
              {FILES.map((file) => {
                const Icon = file.icon;
                const isActive = activeTab === file.id;
                return (
                  <button
                    key={file.id}
                    onClick={() => setActiveTab(file.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all text-left ${isActive ? "bg-slate-800/80 text-white font-medium border-l-2 border-blue-500" : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"}`}
                  >
                    <span className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${isActive ? "text-blue-400" : "text-slate-500"}`} />
                      {file.name}
                    </span>
                    <span className="text-[10px] text-slate-600 group-hover:text-slate-400">{file.size}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Core System Readout */}
          <div className="mt-auto border-t border-slate-800/80 pt-4 px-2">
            <div className="text-[10px] font-bold tracking-widest text-slate-500 uppercase mb-2">SYSTEM PARAMETERS</div>
            <div className="space-y-1 text-[10px] text-slate-500">
              <div className="flex justify-between">
                <span>STATUS:</span>
                <span className="text-[#34A853] font-bold">ONLINE</span>
              </div>
              <div className="flex justify-between">
                <span>ROLE:</span>
                <span className="text-slate-300">UX RESEARCHER</span>
              </div>
              <div className="flex justify-between">
                <span>TARGET:</span>
                <span className="text-blue-400">GOOGLE NEXT</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center / Right Panel: Code Editor View */}
        <div className="flex-1 flex flex-col bg-slate-950">
          
          {/* Top Bar Tabs */}
          <div className="flex bg-slate-900/20 border-b border-slate-800/80 overflow-x-auto">
            {FILES.map((file) => (
              <button
                key={file.id}
                onClick={() => setActiveTab(file.id)}
                className={`px-6 py-3 border-r border-slate-800/80 text-xs font-mono transition-all flex items-center gap-2 shrink-0 ${activeTab === file.id ? "bg-slate-950 text-slate-200 border-t-2 border-blue-500 font-medium" : "text-slate-500 hover:bg-slate-900 hover:text-slate-300"}`}
              >
                <span>{file.name}</span>
              </button>
            ))}
          </div>

          {/* Active Terminal / Content Display */}
          <div className="p-6 sm:p-8 flex-1 flex flex-col">
            <AnimatePresence mode="wait">
              {activeTab === "ux_research" && (
                <motion.div
                  key="ux_research"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                    <span>PATH: src/research/google_ux_research.md</span>
                    <span>&bull;</span>
                    <span className="text-blue-400">RENDERED VIEW</span>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-display text-2xl font-bold text-slate-50">
                      Google UX Research Program & Community Leadership
                    </h3>
                    <p className="text-slate-400 font-light leading-relaxed">
                      Securing selection into the Google User Experience Research program as an independent high school contributor allowed me to help optimize alpha Android system schemas and localized localization modeling.
                    </p>
                  </div>

                  {/* Insight Quote Card */}
                  <div className="relative bg-slate-900/50 border border-slate-800 p-6 rounded-2xl flex gap-4 items-start shadow-xl shadow-black/20">
                    <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                      <Terminal className="w-5 h-5" />
                    </div>
                    <div className="space-y-2">
                      <div className="text-xs font-mono text-slate-500 font-bold">MILSTONE ACCELERATION LOG</div>
                      <p className="text-slate-300 italic font-mono text-sm leading-relaxed">
                        "Ek Form Hi To Fill Krna Hai..." - Filled out a public application form and leveraged community-based credentials to build a personal brand focused on self-taught engineering within the Google developer ecosystem.
                      </p>
                    </div>
                  </div>

                  {/* Core Achievements list */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-900/30 border border-slate-800/80 rounded-xl space-y-2">
                      <div className="flex items-center gap-2 text-xs font-mono text-[#34A853] font-bold">
                        <CheckCircle className="w-4 h-4" /> LOCALIZATION FOCUS
                      </div>
                      <p className="text-xs text-slate-400">
                        Driving community-driven data collection, open-source training parameters, and localized language optimizations.
                      </p>
                    </div>
                    <div className="p-4 bg-slate-900/30 border border-slate-800/80 rounded-xl space-y-2">
                      <div className="flex items-center gap-2 text-xs font-mono text-blue-400 font-bold">
                        <Zap className="w-4 h-4" /> USER-CENTRIC SCHEMAS
                      </div>
                      <p className="text-xs text-slate-400">
                        Reporting digital system friction directly to engineers to simplify layouts and optimize navigation models.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "accessibility" && (
                <motion.div
                  key="accessibility"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                    <span>PATH: config/ecosystems/universal_accessibility.json</span>
                    <span>&bull;</span>
                    <span className="text-green-400">SCHEMATIC DESIGN</span>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-display text-2xl font-bold text-slate-50">
                      Theoretical Google Accessibility Ecosystem
                    </h3>
                    <p className="text-slate-400 font-light leading-relaxed">
                      A self-initiated concept design providing multi-dimensional navigation, speech, and haptic feedback frameworks for the roughly 285 million visually impaired individuals globally.
                    </p>
                  </div>

                  {/* Interactive Watch Simulator Trigger */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Phone Dimension */}
                    <div className="p-5 neon-glow-blue-green rounded-xl space-y-3 relative group">
                      <div className="p-2 w-fit bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-lg">
                        <Database className="w-4 h-4" />
                      </div>
                      <h4 className="text-sm font-bold text-slate-200">Google Phone Integration</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Leveraging Gemini AI's live video API feed to parse physical surroundings and speak clear, localized spatial descriptions.
                      </p>
                    </div>

                    {/* Haptic Watch */}
                    <div className={`p-5 neon-glow-[#FBBC05] rounded-xl space-y-3 relative cursor-pointer transition-all`}
                      onClick={() => setActiveWatchHaptics(!activeWatchHaptics)}
                    >
                      <div className="flex justify-between items-start">
                        <div className="p-2 bg-[#FBBC05]/10 border border-[#FBBC05]/20 text-[#FBBC05] rounded-lg">
                          <Cpu className="w-4 h-4" />
                        </div>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${activeWatchHaptics ? "bg-[#FBBC05]/25 text-[#FBBC05] animate-pulse" : "bg-slate-800 text-slate-500"}`}>
                          {activeWatchHaptics ? "HAPTIC_ACTIVE" : "SIMULATOR"}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-200">Haptic Pixel Watch</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Translating lidar proximity points into micro-vibration vectors. Hover or click to simulate varying obstacle warnings.
                      </p>
                    </div>

                    {/* Glasses */}
                    <div className="p-5 neon-glow-blue-green rounded-xl space-y-3">
                      <div className="p-2 w-fit bg-[#34A853]/10 border border-[#34A853]/20 text-[#34A853] rounded-lg">
                        <Eye className="w-4 h-4" />
                      </div>
                      <h4 className="text-sm font-bold text-slate-200">Intelligent Glasses</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        A hands-free micro-camera wearable utilizing a 180-degree visual tracking arc to grant navigation independence.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "stateless_search" && (
                <motion.div
                  key="stateless_search"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                    <span>PATH: src/engine/stateless_search_engine.rs</span>
                    <span>&bull;</span>
                    <span className="text-purple-400">RUST SOURCE CODE</span>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-display text-2xl font-bold text-slate-50">
                      Minimalist Database-less Stateless Search Architecture
                    </h3>
                    <p className="text-slate-400 font-light leading-relaxed">
                      Engineering clean, memory-efficient data routing algorithms. Emphasizing the UX value of zero-overhead latency pipelines.
                    </p>
                  </div>

                  {/* Simulated Rust Code Block */}
                  <div className="bg-black/80 border border-slate-800/80 p-5 rounded-xl font-mono text-[11px] text-slate-300 overflow-x-auto leading-relaxed shadow-inner">
                    <span className="text-purple-400">pub struct</span> <span className="text-blue-400">StatelessSearchEngine</span> &#123;<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;query: <span className="text-green-400">String</span>,<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;latency_target_ms: <span className="text-yellow-400">u32</span>,<br />
                    &#125;<br /><br />
                    <span className="text-purple-400">impl</span> <span className="text-blue-400">StatelessSearchEngine</span> &#123;<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;<span className="text-purple-400">pub fn</span> <span className="text-yellow-400">route_query</span>(&self) -&gt; <span className="text-green-400">Result</span>&lt;<span className="text-blue-400">Response</span>, <span className="text-red-400">Error</span>&gt; &#123;<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-slate-500">// Bypassing classic database indexing bottlenecks</span><br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-slate-500">// Resolving queries via stateless parallel localized nodes</span><br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-blue-400">Ok</span>(<span className="text-blue-400">Response</span>::new(<span className="text-green-400">"SUCCESS"</span>))<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&#125;<br />
                    &#125;
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
