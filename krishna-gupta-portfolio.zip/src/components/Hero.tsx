import { motion } from "motion/react";
import { ArrowRight, Mail, Sparkles, Terminal } from "lucide-react";
import { NeuralCore } from "./NeuralCore";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.1,
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
  }
};

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex flex-col justify-center pt-12 pb-16" aria-labelledby="hero-heading">
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center"
      >
        <div className="lg:col-span-7 flex flex-col justify-center">
          <motion.div 
            variants={itemVariants} 
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/60 border border-slate-800 backdrop-blur-md mb-8 w-fit shadow-lg shadow-black/20"
          >
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-xs font-mono text-slate-300 flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-blue-400" /> MR. DEVELOPER // HIGH SCHOOL PRODIGY (CLASS 11)
            </span>
          </motion.div>

          <motion.h1 
            id="hero-heading"
            variants={itemVariants}
            className="font-display text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight text-slate-50 leading-[1.1] mb-8"
          >
            Designing for Everyone. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-red-400 via-yellow-400 to-green-400">
              Quantifying the Human Experience.
            </span>
          </motion.h1>
          
          <motion.p 
            variants={itemVariants}
            className="text-lg md:text-xl text-slate-400 max-w-2xl leading-relaxed mb-12 font-light"
          >
            I am <strong className="font-semibold text-slate-200">Krishna Gupta</strong>, a 16-year-old tech pioneer, Google UI/UX Research participant, and Student Ambassador specializing in ultra-accessible digital ecosystems.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 sm:items-center">
            <a 
              href="#research" 
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-slate-50 text-slate-950 rounded-full font-medium hover:bg-slate-200 transition-all focus:ring-2 focus:ring-offset-2 focus:ring-slate-50 focus:ring-offset-slate-950 focus:outline-none shadow-lg shadow-white/5 hover:shadow-white/10"
              aria-label="View Research Projects"
            >
              View Research
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
            </a>
            <a 
              href="#social" 
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-slate-900/50 backdrop-blur-md border border-slate-800 text-slate-50 rounded-full font-medium hover:bg-slate-800 hover:border-slate-700 transition-all focus:ring-2 focus:ring-offset-2 focus:ring-slate-50 focus:ring-offset-slate-950 focus:outline-none"
              aria-label="Connect Professionally"
            >
              Connect Professionally
              <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" aria-hidden="true" />
            </a>
          </motion.div>
        </div>

        {/* Dynamic, interactive Neural Core side panel representing thinking speed and cognitive depth */}
        <motion.div 
          variants={itemVariants}
          className="lg:col-span-5 flex items-center justify-center"
        >
          <div className="relative p-6 w-full max-w-md bg-slate-900/30 border border-slate-800/80 rounded-3xl backdrop-blur-md shadow-2xl shadow-black/50">
            {/* Visual background indicator lines */}
            <div className="absolute top-4 left-4 text-[10px] font-mono text-slate-600">SYS_MATRIX // CORE_INIT</div>
            <div className="absolute top-4 right-4 text-[10px] font-mono text-slate-600 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-yellow-500 animate-pulse" /> HOVER TO STIMULATE
            </div>
            
            <NeuralCore />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}

