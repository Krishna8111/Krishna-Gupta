import { motion } from "motion/react";

const skills = [
  "Human-Computer Interaction (HCI)",
  "Inclusive Design & WCAG 2.1",
  "Cloud Infrastructure",
  "AI Crowdsourcing",
  "Product Architecture",
  "Localization Modeling"
];

export function About() {
  return (
    <section id="about" className="py-24 border-t border-slate-800/30 relative" aria-labelledby="about-heading">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24 items-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, rotate: -2 }}
          whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-5 relative"
        >
          {/* Decorative background glow for the image */}
          <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full transform -translate-x-1/4 translate-y-1/4" />
          
          <div className="aspect-[4/5] neon-glow-container rounded-3xl overflow-hidden relative shadow-2xl shadow-black/50">
            <img 
              src="https://media.licdn.com/dms/image/v2/D5603AQHZUo3Jznwsiw/profile-displayphoto-crop_800_800/B56Z71BfymIMAI-/0/1782227272496?e=1784764800&v=beta&t=tzT5-6MXdEk31Su_7-Ps-sCHLEa8y7Qa_mH0SaS45ew" 
              alt="Krishna Gupta" 
              className="w-full h-full object-cover opacity-85 mix-blend-luminosity hover:mix-blend-normal hover:opacity-100 transition-all duration-700 relative z-10"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none z-20" />
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-7 flex flex-col justify-center"
        >
          <h2 id="about-heading" className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-50 mb-8 tracking-tight">
            Engineering Empathy.
          </h2>
          
          <div className="prose prose-lg prose-invert prose-slate max-w-none mb-12 text-slate-400">
            <p className="leading-relaxed mb-6 font-light text-lg">
              Operating under the developer moniker <strong className="text-slate-200 font-medium">Mr. Developer</strong>, I am a 16-year-old high school student (Class 11) based in New Delhi, India. I balance formal education with independent tech projects, advocating for unconventional learning and direct, project-based build portfolios.
            </p>
            <p className="leading-relaxed mb-6 font-light text-lg">
              My journey gained substantial traction in early 2026 across professional networks after securing a role as a <strong className="text-slate-200 font-medium">Google UX Research participant</strong> and <strong className="text-slate-200 font-medium">Google Student Ambassador</strong>. My viral posts humorously noted that I simply filled out a public application form (<em className="text-slate-300 not-italic font-medium">"Ek Form Hi To Fill Krna Hai..."</em>), leveraging this community-based credential to build a personal brand focused on self-taught engineering.
            </p>
            <p className="leading-relaxed font-light text-lg">
              My core philosophy centers on developing intuitive, friction-free digital workflows specifically designed for visually impaired users. I firmly believe that <em className="text-slate-300 not-italic font-medium">accessibility is the cornerstone of true innovation</em>, not merely an afterthought. Through AI crowdsourcing and localized modeling, I strive to make technology natively fluent in every human experience.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold tracking-widest text-slate-500 uppercase mb-6" id="skills-heading">Core Competencies</h3>
            <ul className="flex flex-wrap gap-3" aria-labelledby="skills-heading">
              {skills.map((skill, i) => (
                <motion.li 
                  key={skill}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 + (i * 0.1), duration: 0.5 }}
                >
                  <span className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-slate-900/40 backdrop-blur-sm border border-slate-700/50 text-slate-300 hover:bg-slate-800 hover:text-slate-100 transition-colors cursor-default">
                    {skill}
                  </span>
                </motion.li>
              ))}
            </ul>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
