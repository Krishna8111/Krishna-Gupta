import { motion, AnimatePresence } from "motion/react";
import { useEffect, useState } from "react";

const BOOT_LOGS = [
  "SYS // COGNITIVE CORE v1.16 ... ACTIVE",
  "SYS // SCANNING HUMAN INTERACTION NODES ... OK",
  "SYS // INITIALIZING ACCESSIBILITY LAYER ... WCAG 2.1 AA",
  "SYS // CONNECTING TO GEMINI NEURAL PATTERNS ... ESTABLISHED",
  "SYS // WELCOME, USER. CURRENT IDENTITY: MR. DEVELOPER"
];

export function BootAnimation() {
  const [isVisible, setIsVisible] = useState(true);
  const [currentLogIdx, setCurrentLogIdx] = useState(0);

  useEffect(() => {
    // Log cycle
    const logInterval = setInterval(() => {
      setCurrentLogIdx((prev) => {
        if (prev < BOOT_LOGS.length - 1) return prev + 1;
        clearInterval(logInterval);
        return prev;
      });
    }, 400);

    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 2800);

    return () => {
      clearInterval(logInterval);
      clearTimeout(timer);
    };
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 font-mono text-xs px-6"
        >
          {/* Neon Grid Background */}
          <div className="absolute inset-0 neural-grid opacity-20 pointer-events-none" />
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-red-500 via-yellow-500 to-green-500" />
          
          <div className="flex gap-4 items-center mb-12 relative z-10">
            <motion.div
              initial={{ y: 0, scale: 0.8 }}
              animate={{ y: [-15, 0, -15], scale: [0.8, 1.2, 0.8] }}
              transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut", delay: 0 }}
              className="w-4 h-4 rounded-full bg-[#4285F4] shadow-[0_0_20px_rgba(66,133,244,0.8)]" 
            />
            <motion.div
              initial={{ y: 0, scale: 0.8 }}
              animate={{ y: [-15, 0, -15], scale: [0.8, 1.2, 0.8] }}
              transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut", delay: 0.15 }}
              className="w-4 h-4 rounded-full bg-[#EA4335] shadow-[0_0_20px_rgba(234,67,53,0.8)]" 
            />
            <motion.div
              initial={{ y: 0, scale: 0.8 }}
              animate={{ y: [-15, 0, -15], scale: [0.8, 1.2, 0.8] }}
              transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut", delay: 0.3 }}
              className="w-4 h-4 rounded-full bg-[#FBBC05] shadow-[0_0_20px_rgba(251,188,5,0.8)]" 
            />
            <motion.div
              initial={{ y: 0, scale: 0.8 }}
              animate={{ y: [-15, 0, -15], scale: [0.8, 1.2, 0.8] }}
              transition={{ repeat: Infinity, duration: 1.0, ease: "easeInOut", delay: 0.45 }}
              className="w-4 h-4 rounded-full bg-[#34A853] shadow-[0_0_20px_rgba(52,168,83,0.8)]" 
            />
          </div>

          <div className="max-w-md w-full bg-black/60 border border-slate-800 rounded-lg p-4 font-mono text-[11px] text-slate-400 relative z-10 backdrop-blur-md">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-3">
              <span className="text-slate-500 font-bold tracking-wider">SECURE BOOT TERMINAL</span>
              <span className="text-blue-400 font-medium">ONLINE</span>
            </div>
            <div className="space-y-1.5 min-h-[100px] flex flex-col justify-end">
              {BOOT_LOGS.slice(0, currentLogIdx + 1).map((log, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`${index === currentLogIdx ? "text-slate-200" : "text-slate-500"}`}
                >
                  <span className="text-blue-500 mr-2">&gt;</span> {log}
                </motion.div>
              ))}
              {currentLogIdx < BOOT_LOGS.length - 1 && (
                <div className="w-1.5 h-3 bg-slate-400 animate-pulse inline-block" />
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

