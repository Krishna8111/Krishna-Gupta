import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Terminal, Shield, Sparkles, Folder, File, Code, Calendar, Globe, MapPin } from "lucide-react";

interface LogEntry {
  id: string;
  year: string;
  title: string;
  role: string;
  location: string;
  description: string;
  details: string[];
}

const LOGS: LogEntry[] = [
  {
    id: "genesis",
    year: "2024",
    title: "Ecosystem Genesis",
    role: "Independent UI Explorer",
    location: "New Delhi, India",
    description: "Began mapping spatial human-computer interaction patterns, building basic web tool prototypes, and researching accessibility parameters.",
    details: [
      "Mapped spatial haptic vectors for micro-interfaces.",
      "Coded stateless UI converters for screen-reader efficiency.",
      "Advocated for clean, dark-mode minimalist wireframes."
    ]
  },
  {
    id: "leadership",
    year: "2025",
    title: "Google Student Community Advocate",
    role: "Student Community Leader",
    location: "India",
    description: "Appointed to lead localized tech study jams, evangelizing cloud architecture maps and AI data modeling configurations.",
    details: [
      "Organized open community UI/UX design workshops.",
      "Promoted localized AI labeling models via Google Crowdsource.",
      "Delivered beginners' guides on configuring database-less servers."
    ]
  },
  {
    id: "research_milestone",
    year: "2026",
    title: "Google UX Research & Viral Milestones",
    role: "Google UX Research Participant & Influencer",
    location: "Remote / Global",
    description: "Gained significant professional traction after sharing acceptance into Google UX Research. Popularized unconventional self-taught learning path.",
    details: [
      "Leveraged community-based credentials to scale personal reach.",
      "Designed the theoretical 'Universal Google Accessibility Ecosystem'.",
      "Published minimalist architectural guides for early-stage developers."
    ]
  }
];

export function InteractiveLogs() {
  const [selectedLogId, setSelectedLogId] = useState<string>("research_milestone");

  const selectedLog = LOGS.find(l => l.id === selectedLogId) || LOGS[2];

  return (
    <section id="logs" className="py-24 border-t border-slate-800/30" aria-labelledby="logs-heading">
      <div className="mb-12">
        <h2 id="logs-heading" className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-50 mb-4 tracking-tight">
          Interactive Journey Logs
        </h2>
        <p className="text-slate-400 text-lg max-w-2xl font-light">
          Explore Krishna's timeline, community impact events, and self-taught engineering milestones.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Timeline Buttons (Left Column) */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          {LOGS.map((log) => {
            const isSelected = log.id === selectedLogId;
            return (
              <button
                key={log.id}
                onClick={() => setSelectedLogId(log.id)}
                className={`w-full text-left p-5 rounded-2xl border transition-all relative overflow-hidden ${isSelected ? "bg-slate-900/60 border-slate-700 shadow-xl shadow-black/20" : "bg-slate-900/10 border-slate-900 hover:border-slate-800 hover:bg-slate-900/20"}`}
              >
                {isSelected && (
                  <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-blue-500" />
                )}
                <div className="flex items-center justify-between mb-2">
                  <span className={`font-mono text-xs font-bold px-2.5 py-1 rounded ${isSelected ? "bg-blue-500/10 text-blue-400" : "bg-slate-800 text-slate-500"}`}>
                    {log.year}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">STATUS: SECURE</span>
                </div>
                <h3 className={`font-display text-base font-bold ${isSelected ? "text-slate-50" : "text-slate-400"}`}>
                  {log.title}
                </h3>
              </button>
            );
          })}
        </div>

        {/* Selected Log Terminal Console (Right Column) */}
        <div className="lg:col-span-8">
          <div className="neon-glow-container rounded-2xl overflow-hidden shadow-2xl shadow-black/80 font-mono text-xs flex flex-col min-h-[380px]">
            {/* Terminal Header */}
            <div className="bg-slate-900/50 px-5 py-3 border-b border-slate-800/80 flex items-center justify-between relative z-10">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                <span className="text-[10px] text-slate-500 ml-2">TERMINAL_LOG // {selectedLog.id.toUpperCase()}</span>
              </div>
              <span className="text-blue-500 text-[10px] flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" /> ENCRYPTED
              </span>
            </div>

            {/* Terminal Console Body */}
            <div className="p-6 sm:p-8 flex-1 flex flex-col gap-6 relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-blue-500/5 to-transparent pointer-events-none" />

              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedLogId}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {/* Metadata Tag Row */}
                  <div className="flex flex-wrap gap-4 text-[10px] text-slate-500 border-b border-slate-900 pb-4">
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3 text-blue-400" /> TIMELINE: {selectedLog.year}</span>
                    <span className="flex items-center gap-1"><Globe className="w-3 h-3 text-red-400" /> INSTANCE: {selectedLog.role}</span>
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-green-400" /> REGION: {selectedLog.location}</span>
                  </div>

                  {/* Summary Text */}
                  <div className="space-y-2">
                    <div className="text-[10px] font-bold text-slate-500 tracking-wider">SUMMARY DESCRIPTION</div>
                    <p className="text-slate-300 leading-relaxed font-light text-sm">
                      {selectedLog.description}
                    </p>
                  </div>

                  {/* Technical Sub-logs */}
                  <div className="space-y-3">
                    <div className="text-[10px] font-bold text-slate-500 tracking-wider">DIAGNOSTIC TELEMETRY LOGS</div>
                    <ul className="space-y-2.5">
                      {selectedLog.details.map((detail, index) => (
                        <li key={index} className="flex gap-3 items-start text-slate-400">
                          <span className="text-[#34A853] mt-0.5">&gt;_</span>
                          <span className="leading-relaxed text-xs">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
