import { motion, useScroll, useSpring } from "motion/react";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1.5 z-40 origin-left flex"
      style={{ scaleX }}
    >
       <div className="h-full bg-[#4285F4] w-1/4 shadow-[0_0_10px_rgba(66,133,244,0.8)]" />
       <div className="h-full bg-[#EA4335] w-1/4 shadow-[0_0_10px_rgba(234,67,53,0.8)]" />
       <div className="h-full bg-[#FBBC05] w-1/4 shadow-[0_0_10px_rgba(251,188,5,0.8)]" />
       <div className="h-full bg-[#34A853] w-1/4 shadow-[0_0_10px_rgba(52,168,83,0.8)]" />
    </motion.div>
  );
}
