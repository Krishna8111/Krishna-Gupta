import { motion } from "motion/react";
import { Terminal, Shield, Sparkles } from "lucide-react";

export function CEOStatement() {
  return (
    <div className="w-full bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40 px-4 py-2.5 flex items-center justify-between text-xs font-mono">
      {/* Decorative timeline coordinates */}
      <div className="flex items-center gap-3 text-slate-500">
        <span className="flex items-center gap-1.5 text-blue-500">
          <Terminal className="w-3.5 h-3.5" /> SECURE_LINK
        </span>
        <span className="hidden sm:inline">|</span>
        <span className="hidden sm:inline">LOC: ND, IN</span>
        <span className="hidden md:inline">|</span>
        <span className="hidden md:inline text-slate-600">STILL_CLASS_11</span>
      </div>

      {/* The Pulsing Bold Marquee / Callout */}
      <div className="flex items-center gap-2 max-w-lg overflow-hidden bg-slate-900/50 border border-slate-800 px-4 py-1.5 rounded-full shadow-inner">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
        </span>
        <div className="font-bold tracking-wider uppercase text-slate-400 flex items-center gap-1.5 text-[10px] sm:text-xs">
          <span>PRIORITY TIMELINE:</span>
          <motion.span 
            className="animate-google-loop font-display tracking-tight text-sm font-bold ml-1"
          >
            "I am the next Google CEO."
          </motion.span>
        </div>
      </div>

      {/* Connection Indicator */}
      <div className="flex items-center gap-2 text-slate-500">
        <span className="hidden lg:inline text-[10px] text-[#34A853]/70 font-semibold bg-[#34A853]/10 border border-[#34A853]/20 px-2 py-0.5 rounded">
          COGNITIVE ENGINE v1.16
        </span>
        <span className="flex items-center gap-1 text-[#34A853]">
          <Shield className="w-3.5 h-3.5" /> SECURE
        </span>
      </div>
    </div>
  );
}
