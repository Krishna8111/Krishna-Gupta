import { motion } from "motion/react";
import { Linkedin, Instagram, Globe } from "lucide-react";

export function Social() {
  return (
    <section id="social" className="py-24 border-t border-slate-800/30" aria-labelledby="social-heading">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center text-center neon-glow-container rounded-3xl p-12 shadow-2xl shadow-black/80"
      >
        <h2 id="social-heading" className="font-display text-3xl sm:text-4xl font-bold text-slate-50 mb-6 tracking-tight">
          Connect & Collaborate
        </h2>
        
        <p className="text-slate-400 max-w-2xl mx-auto mb-12 font-light text-lg">
          Open to research discussions, speaking engagements on accessibility, and collaborations across the digital ecosystem.
        </p>

        <div className="flex flex-wrap justify-center gap-6">
          <a
            href="https://linkedin.com/in/krishna-gupta-a3602b235"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 px-8 py-4 bg-slate-900/50 border border-slate-700/50 rounded-full hover:bg-[#0A66C2]/10 hover:border-[#0A66C2]/30 transition-all duration-300 focus:ring-2 focus:ring-[#0A66C2]/50 focus:outline-none"
            aria-label="Connect on LinkedIn"
          >
            <Linkedin className="w-5 h-5 text-slate-400 group-hover:text-[#0A66C2] transition-colors" aria-hidden="true" />
            <span className="font-medium text-slate-300 group-hover:text-white transition-colors">LinkedIn</span>
          </a>

          <a
            href="https://instagram.com/krishnagupta.io"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 px-8 py-4 bg-slate-900/50 border border-slate-700/50 rounded-full hover:bg-pink-500/10 hover:border-pink-500/30 transition-all duration-300 focus:ring-2 focus:ring-pink-500/50 focus:outline-none"
            aria-label="Follow on Instagram"
          >
            <Instagram className="w-5 h-5 text-slate-400 group-hover:text-pink-500 transition-colors" aria-hidden="true" />
            <span className="font-medium text-slate-300 group-hover:text-white transition-colors">@krishnagupta.io</span>
          </a>

          <a
            href="https://krishnagupta.io"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 px-8 py-4 bg-slate-900/50 border border-slate-700/50 rounded-full hover:bg-emerald-500/10 hover:border-emerald-500/30 transition-all duration-300 focus:ring-2 focus:ring-emerald-500/50 focus:outline-none"
            aria-label="Visit Personal Domain"
          >
            <Globe className="w-5 h-5 text-slate-400 group-hover:text-emerald-500 transition-colors" aria-hidden="true" />
            <span className="font-medium text-slate-300 group-hover:text-white transition-colors">krishnagupta.io</span>
          </a>
        </div>
      </motion.div>
    </section>
  );
}
